class Guest < ApplicationRecord
end
