class Organization < ApplicationRecord
end
