class AdminOrg < ApplicationRecord
end
